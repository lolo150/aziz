import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
import pandas as pd 
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
import json
warnings.filterwarnings("ignore")
#Let's load the data and look at them
df= pd.read_csv('C:\\Users\\EM\\Desktop\\vscode\\mol\\Data.csv', names=['smiles', 'logP'])
data='C:\\Users\\EM\\Desktop\\vscode\\mol\\Data.csv'
moleculs = pd.read_csv(data)
moleculs.head()
feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
X = moleculs[feature_names]
y = moleculs['class']
# Create Training and Test Sets and Apply Scaling
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
# Models
# K-Nearest Neighbors   
knn = KNeighborsClassifier()
knn.fit(X_train, y_train)
print('Accuracy of K-NN classifier on training set: {:.2f}'.format(knn.score(X_train, y_train)))
print('Accuracy of K-NN classifier on test set: {:.2f}'.format(knn.score(X_test, y_test)))

