from rdkit import Chem
from rdkit.Chem import AllChem
from molmass import Formula
# Using readlines()
file1 = open('Smiles.txt', 'r')
Lines = file1.readlines()
Atom=[]
List = []
Mass = []
Descripto = []
count = 0
# Strips the newline character
for line in Lines:
    m2 = Chem.MolFromSmiles(line.strip())
    List.append(m2.GetNumAtoms())


for atome in List:
    Atom.append(str(atome)+'\n')
    # writing to file
    file1 = open('atome.txt', 'w')
    file1.writelines(Atom)
    file1.close()


from rdkit.Chem.Descriptors import ExactMolWt


# Molecale weight
for line in Lines:
     Masse=str(ExactMolWt(Chem.MolFromSmiles( line.strip())))+'\n'
     Mass.append(Masse)
     # writing to file
     file1 = open('weight.txt', 'w')
     file1.writelines(Mass)
     file1.close()



from rdkit.Chem import Descriptors
# Descriptors
for line in Lines:
    Descripter=Descriptors.TPSA(Chem.MolFromSmiles(line.strip()))
    Descripto.append(str(Descripter)+'\n')
    # writing to file
    file1 = open('ESOL.txt', 'w')
    file1.writelines(Descripto)
    file1.close()

# foscarnet
