from flask import Flask, request, render_template,jsonify
from werkzeug.utils import secure_filename
import pandas as pd 
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
import numpy as np
import json

# Data
Tests = []
data= 'C:\\Users\\PC\\Desktop\\mol\\mol\\DataLabeld-1.csv'
data2='C:\\Users\\PC\\Desktop\\mol\\mol\\DataLabeld-1.csv'
data3='C:\\Users\\PC\\Desktop\\mol\\mol\\DataLabeld-1.csv'
data4='C:\\Users\\PC\\Desktop\\mol\\mol\\DataLabeld-1.csv'
def  K_Nearest_Neighbors(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # K-Nearest Neighbors   
        knn = KNeighborsClassifier()
        knn.fit(X_train, y_train)
        print('Accuracy of K-NN classifier on training set: {:.2f}'.format(knn.score(X_train, y_train)))
        print('Accuracy of K-NN classifier on test set: {:.2f}'.format(knn.score(X_test, y_test)))
        Accuracy_training='Accuracy of Decision Tree classifier on training set: {:.2f}'.format(knn.score(X_train, y_train))
        Accuracy_test = 'Accuracy of Decision Tree classifier on test set: {:.2f}'.format(knn.score(X_test, y_test))

        Tests = svm.predict(X_test).tolist()
        return Accuracy_training,Accuracy_test,Tests

def Gaussian_Naive_Bayes(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # Gaussian Naive Bayes   
        gnb = GaussianNB()
        gnb.fit(X_train, y_train)
        print('Accuracy of GNB classifier on training set: {:.2f}'.format(gnb.score(X_train, y_train)))
        print('Accuracy of GNB classifier on test set: {:.2f}'.format(gnb.score(X_test, y_test)))
        Accuracy_training='Accuracy of Decision Tree classifier on training set: {:.2f}'.format(gnb.score(X_train, y_train))
        Accuracy_test = 'Accuracy of Decision Tree classifier on test set: {:.2f}'.format(gnb.score(X_test, y_test))
        Tests = gnb.predict(X_test).tolist()
        return Accuracy_training, Accuracy_test, Tests


def Support_Vector_Machine(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # Support Vector Machine  
        svm = SVC()
        svm.fit(X_train, y_train)
        print('Accuracy of SVM classifier on training set: {:.2f}'.format(svm.score(X_train, y_train)))
        print('Accuracy of SVM classifier on test set: {:.2f}'.format(svm.score(X_test, y_test)))
        Accuracy_training='Accuracy of Decision Tree classifier on training set: {:.2f}'.format(svm.score(X_train, y_train))
        Accuracy_test = 'Accuracy of Decision Tree classifier on test set: {:.2f}'.format(svm.score(X_test, y_test))
        Tests = svm.predict(X_test).tolist()
        return Accuracy_training,Accuracy_test,Tests

def  Decision_Tree_prediction(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # 1-Decision Tree
        clf = DecisionTreeClassifier().fit(X_train, y_train)
        print('Accuracy of Decision Tree classifier on training set: {:.2f}'.format(clf.score(X_train, y_train)))
        print('Accuracy of Decision Tree classifier on test set: {:.2f}'.format(clf.score(X_test, y_test)))
        Accuracy_training='Accuracy of Decision Tree classifier on training set: {:.2f}'.format(clf.score(X_train, y_train))     
         # Numpy to List of the prediction
        Tests=clf.predict(X_test).tolist()
        print(Tests)
        return Tests 
 
def  Decision_Tree(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # 1-Decision Tree
        clf = DecisionTreeClassifier().fit(X_train, y_train)
        print('Accuracy of Decision Tree classifier on training set: {:.2f}'.format(clf.score(X_train, y_train)))
        print('Accuracy of Decision Tree classifier on test set: {:.2f}'.format(clf.score(X_test, y_test)))
        Accuracy_training='Accuracy of Decision Tree classifier on training set: {:.2f}'.format(clf.score(X_train, y_train))     
         # Numpy to List of the prediction
        Tests=clf.predict(X_test).tolist()
        print(Tests)
        return Accuracy_training 

def  Decision_Tree_Test(path):
        Tests = []
        moleculs = pd.read_csv(path)
        moleculs.head()
        feature_names = ['ESOL', 'Molecular Weight', 'Number of H-Bond Donors', 'Number of Rings','Number of Rotatable Bonds']
        X = moleculs[feature_names]
        y = moleculs['class']
        # Create Training and Test Sets and Apply Scaling
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        scaler = MinMaxScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        # Models
        # 1-Decision Tree
        clf = DecisionTreeClassifier().fit(X_train, y_train)
        print('Accuracy of Decision Tree classifier on training set: {:.2f}'.format(clf.score(X_train, y_train)))
        print('Accuracy of Decision Tree classifier on test set: {:.2f}'.format(clf.score(X_test, y_test)))
        Accuracy_test='Accuracy of Decision Tree classifier on test set: {:.2f}'.format(clf.score(X_test, y_test))
        return Accuracy_test
        
# this ML
# from fs  import open_fs
app = Flask(__name__)
array=[]
x = "awesome"
@app.route('/')
def home():
    return render_template('home.html')
@app.route('/home')
def home2():
    return render_template('home.html')


@app.route('/main')
def main():
	"""Main URL to test Chart.js"""

	n, bins = 10000, 20
	normal = np.random.normal(0, 1, n)
	gumbel = np.random.gumbel(0, 1, n)
	weibull = np.random.weibull(5, n)
	nhistogram = np.histogram(normal, bins=bins)
	ghistogram = np.histogram(gumbel, bins=bins)
	whistogram = np.histogram(weibull, bins=bins)

	return render_template('main.html',
							nvalues=nhistogram[0].tolist(),
							nlabels=nhistogram[1].tolist(),
							ncolor='rgba(50, 115, 220, 0.4)',
							gvalues=ghistogram[0].tolist(),
							glabels=ghistogram[1].tolist(),
							gcolor='rgba(0, 205, 175, 0.4)',
							wvalues=whistogram[0].tolist(),
							wlabels=whistogram[1].tolist(),
							wcolor='rgba(255, 56, 96, 0.4)')

@app.route('/index')
def index():
    return render_template('index.html')
    
@app.route('/Comparaison')
def Comparaison():
    return render_template('Comparison.html')
    
    
@app.route('/Prediction')
def Prediction():
    return render_template('prediction.html')
dict_Mol = {
"Amigdalin": 1,
"Fenfuram": 2,
"citral": 3,
"Picene": 4,
"Thiophene": 5,
"benzothiazole": 6,
"Estradiol": 7,
"Dieldrin": 8
}
def finde_index(Name_Mol):
    index=dict_Mol[Name_Mol]
    return index

# Prediction_post
@app.route('/predict', methods=['GET','POST'])
def Prediction_post():
    finalarray=[]
    model = request.form['ip']
    Dones  = request.form['Dones']
    # Decision Tree
    if model == 'Support Vector Machine':

        Accuracy_training,Accuracy_test,Tests = Support_Vector_Machine(data)
        index=finde_index(Dones)
        Result_Prediction=Tests[index]
    elif model == 'Gaussian Naive Bayes':
        Accuracy_training, Accuracy_test, Tests = Gaussian_Naive_Bayes(data)
        index = finde_index(Dones)
        Result_Prediction = Tests[index]
        print('Decision Tree')
    elif   model == 'K-Nearest Neighbors':
        Accuracy_training, Accuracy_test, Tests = Support_Vector_Machine(data)
        index = finde_index(Dones)
        Result_Prediction = Tests[index]
    elif model == 'Decision Tree':
        Tests = Decision_Tree_prediction(data)
        index = finde_index(Dones)
        Result_Prediction = Tests[index]
    print(type(Result_Prediction))
    print(Dones)
    # Decision Tree
    saut='\n'
    result = {

         "saut": saut,
        "Tests": Result_Prediction
        
    }
    # result = {str(value): value for key, value in result.items()}

    return jsonify(result=result)
   
   # Classification_post
@app.route('/join', methods=['GET','POST'])
def Classification_post():
    finalarray=[]
    model = request.form['ip']
    Dones  = request.form['Dones']
# Decision Tree
    if model =='Decision Tree' and Dones =='Train/Test Data 1':
         print('Decision Tree')      
         Tests=Decision_Tree_prediction(data)
         Accuracy_training=Decision_Tree(data)
         Accuracy_test= Decision_Tree_Test(data)
    elif model == 'Decision Tree' and Dones =='Train/Test Data 2':
         print('Decision Tree Data 2')
         Tests=Decision_Tree_prediction(data2)
         Accuracy_training=Decision_Tree(data2)
         Accuracy_test= Decision_Tree_Test(data2)    
         
    elif model == 'Decision Tree' and Dones =='Train/Test Data 3':
         print('Decision Tree Data 3')
         Tests=Decision_Tree_prediction(data3)
         Accuracy_training=Decision_Tree(data3)
         Accuracy_test= Decision_Tree_Test(data3)
         
    elif model == 'Decision Tree' and Dones =='Train/Test Data 4':
         print('Decision Tree Data 4')
         Tests=Decision_Tree_prediction(data4)
         Accuracy_training=Decision_Tree(data4)
         Accuracy_test= Decision_Tree_Test(data4)
# Gaussian Naive Bayes
         
    elif model == 'Gaussian Naive Bayes' and  Dones =='Train/Test Data 1':
         Accuracy_training,Accuracy_test = Gaussian_Naive_Bayes(data)

         print('Gaussian Naive Bayes  Data 1')
    elif model == 'Gaussian Naive Bayes' and  Dones =='Train/Test Data 2':
         Accuracy_training, Accuracy_test = Gaussian_Naive_Bayes(data2)
         print('Gaussian Naive Bayes  Data 2') 
    elif model == 'Gaussian Naive Bayes' and  Dones =='Train/Test Data 3':
         Accuracy_training, Accuracy_test = Gaussian_Naive_Bayes(data3)
         print('Gaussian Naive Bayes  Data 3')
         
    elif model == 'Gaussian Naive Bayes' and  Dones =='Train/Test Data 4':
         Accuracy_training,Accuracy_test = Gaussian_Naive_Bayes(data4)
         print('Gaussian Naive Bayes  Data 4')
         
         
# K-Nearest Neighbors
    elif model == 'K-Nearest Neighbors' and  Dones =='Train/Test Data 1':
         Accuracy_training,Accuracy_test = K_Nearest_Neighbors(data)
         print('K-Nearest Neighbors Data 1')
    elif model == 'K-Nearest Neighbors' and  Dones =='Train/Test Data 2':
         Accuracy_training, Accuracy_test = K_Nearest_Neighbors(data2)
         print('K-Nearest Neighbors Data 2') 
    elif model == 'K-Nearest Neighbors' and  Dones =='Train/Test Data 3':
         Accuracy_training, Accuracy_test = K_Nearest_Neighbors(data3)
         print('K-Nearest Neighbors Data 3')
         
    elif model == 'K-Nearest Neighbors' and  Dones =='Train/Test Data 4':
         Accuracy_training, Accuracy_test = K_Nearest_Neighbors(data4)
         print('K-Nearest Neighbors Data 4')

# Support Vector Machine
    elif model == 'Support Vector Machine' and  Dones =='Train/Test Data 1':
         Accuracy_training, Accuracy_test = Support_Vector_Machine(data)
         print('Support Vector Machine Data 1  ')
    elif model == 'Support Vector Machine' and  Dones =='Train/Test Data 2':
         Accuracy_training, Accuracy_test = Support_Vector_Machine(data2)
         print('Support Vector Machine Data 2  ') 
    elif model == 'Support Vector Machine' and  Dones =='Train/Test Data 3':
         Accuracy_training, Accuracy_test = Support_Vector_Machine(data3)
         print('Support Vector Machine Data 3  ')
         
    elif model == 'Support Vector Machine' and  Dones =='Train/Test Data 4':
         Accuracy_training, Accuracy_test = Support_Vector_Machine(data4)
         print('Support Vector Machine  Data 4 ')     
       
    saut='\n'
    # Accuracy_training=''
    # Accuracy_test=''
    result = {
        "Accuracy_training": Accuracy_training,
        "saut": saut,
        "Accuracy_test": Accuracy_test,
        "Tests": saut
        
    }    #result = {str(value): value for key, value in result.items()}
    
    return jsonify(result=result)




   
	
   
if __name__ == '__main__':
    app.run(debug=True)