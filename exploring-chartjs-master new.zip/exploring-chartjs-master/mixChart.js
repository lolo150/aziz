
var labels = [
    "Decision Tree",
    "K-Nearest Neighbors",
    "Gaussian Naive Bayes",
    "Support Vector Machine",
   
];
var revenues = [
    95,
    65,
    96,
    48
    
];
var clients = [
    300,
    140,
    80,
    150
   
];



var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [{
            label: 'My First dataset',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: ' #00ff55',
            data: [0, 10, 5, 2, 20, 30, 45]
        }]
    },

    // Configuration options go here
    options: {}
});

var mix = document.getElementById("mixChart").getContext('2d');
var mixChart = new Chart(mix, {
    type: 'bar',
    data: {
        labels: labels,
        datasets: [
            {
                type: 'line',
                label: "Tests",
                data: revenues,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                yAxisID: 'revenues',
            },
            {
                label: "Training",
                data: clients,
                borderColor: 'rgba(0, 0, 0, 0)',
                backgroundColor: 'rgba(192, 75, 192, 0.5)',
                yAxisID: 'clients',
            }
        ]
    },
    options: {
        scales: {
            yAxes: [
                {
                    id: "revenues",
                    ticks: {
                        beginAtZero: true,
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'ََAccuracy Tests'
                      }
                },
                {
                    id: "clients",
                    position: 'right',
                    ticks: {
                        beginAtZero: true,
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Accuracy Training'
                      }
                },
            ]
        },
    }
});

